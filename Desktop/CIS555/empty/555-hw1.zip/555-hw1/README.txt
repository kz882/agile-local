CIS555 Spring 2021 Homework 1 Milestone 1
Kailin Zheng, Feb 17, 2021

Please check here for explanation of my implementation.

Part 1. Test cases:
The tests cases are in src/test/java/edu.upenn.cis.cis455.m1.server, named as "TestFileRequestHanlder.java".
Please make sure to put everything in the same directory as is.

- testFileRequestHandler() tests a GET /index.html request
1. assert byte[] of response body
2. assert content type 'text/html'

- test404() tests a GET /qqq request
3. assert response status 404

- test403() tests a GET ../mydir/index.html request
Note that this directory exists, but outside the root_dir=/www which is the same level as mydir
4. assert response status 403

- testWWW() tests a GET ../www request
When the path is a directory, look for index.html
5. assert byte[] of response body
6. assert content type 'text/html'

Part 2. shutdown
After clicking the shutdown on the main page, a new shutdown.html page will be returned.
Make sure to include shutdown.html in the root directory.
If you shut down the server, you will need to rerun the program to restart the server.

Part 3. control
The page will show up with status of each worker thread and an option to shutdown the server.


