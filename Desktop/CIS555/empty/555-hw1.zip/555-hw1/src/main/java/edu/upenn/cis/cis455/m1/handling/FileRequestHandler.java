package edu.upenn.cis.cis455.m1.handling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;

public class FileRequestHandler {
	private static String rootDir = "./www";
	final static Logger logger = LogManager.getLogger(FileRequestHandler.class);
	
	public String getRootDir() {
		return rootDir;
	}

	public static void setRootDir(String rootDir) {
		FileRequestHandler.rootDir = rootDir;
	}


	/**
	 * Modify response according to GET request
	 * Expect and handle 200, 403, 404 status
	 */
	public static void handle(HttpRequest request, HttpResponse response) {
		logger.info("Attempting to retrieve file");
		Path rootPath = Paths.get(rootDir);
		Path inputPath = Paths.get(request.uri());
		
		try { 
			File myfile = new File(rootPath.toFile(), inputPath.toString());
			if(myfile.isDirectory()) {
				myfile = myfile.toPath().resolve("index.html").toFile();
			}

			if (!myfile.exists()) {
				response.status(404);
				return;
			}
					
			if(!myfile.getCanonicalPath().startsWith(Paths.get(rootDir).toFile().getCanonicalPath()) || !myfile.canRead()) {
				response.status(403);
				return;
			}

			logger.info("Getting path");
			Path path = myfile.toPath();
			response.status(200);

			// write the MIME type to response content-type field
			response.type(Files.probeContentType(path));

			//write the file to the body of the response
			byte[] file = Files.readAllBytes(path);
			response.bodyRaw(file);
			// write the content length to the response field
			response.length(file.length);
			
//			//check for if-modified since and if-unmodified-since
//			String if_modified_since = request.headers("")
//			response.addHeader("If-Modified-Since: ", since.toGMTString());

		} catch(Exception e) {
			response.status(400);
			return;
		}		
	}
}
