package edu.upenn.cis.cis455.m1.handling;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.cis.cis455.HttpParsing;
import edu.upenn.cis.cis455.exceptions.HaltException;
import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;
import edu.upenn.cis.cis455.m1.interfaces.Request;
import edu.upenn.cis.cis455.m1.interfaces.Response;
import edu.upenn.cis.cis455.m1.server.WebService;

/**
 * Handles marshaling between HTTP Requests and Responses
 */
public class HttpIoHandler {
    final static Logger logger = LogManager.getLogger(HttpIoHandler.class);
    static Map<Integer, String> codeToBody  = new HashMap<Integer, String>() {/**
		 * 
		 */
		private static final long serialVersionUID = 4601236138302735259L;

	{
        put(200, "OK");
        put(400, "Bad Request");
        put(403, "Forbidden");
        put(404, "Not Found");
    }};
    
    /**
     * Sends an exception back, in the form of an HTTP response code and message.
     * Returns true if we are supposed to keep the connection open (for persistent
     * connections).
     */
    public static boolean sendException(Socket socket, Request request, HaltException except) {
		try {
			String initial_line = "HTTP/1.1 " + except.statusCode() + " " + except.body() + "\r\n";
			
			logger.info("Sending Exception, initial line: " + initial_line);
			
			socket.getOutputStream().write(initial_line.getBytes());
			socket.getOutputStream().flush();
			socket.getOutputStream().close();
	    	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return true;
    }

    /**
     * Sends data back. Returns true if we are supposed to keep the connection open
     * (for persistent connections).
     */
    public static boolean sendResponse(Socket socket, Request request, Response response) {
    	logger.info("Send Response");
    	String initial_line = "HTTP/1.1 " + response.status()  + " " + codeToBody.get(response.status()) + "\r\n";
    	try {
			socket.getOutputStream().write(initial_line.getBytes());
			socket.getOutputStream().write(response.getHeaders().getBytes());
	    	if (request.requestMethod().equals("GET")) {
	    		socket.getOutputStream().write("\r\n".getBytes());
	    		socket.getOutputStream().write(response.bodyRaw());
	    	}
	    	socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return true;
    }
    
    public static HttpRequest handleRequest(String worker_url, WebService webservice, Socket socket) {
		//Parse request by HttpParsing
    	Map<String, String> headers = new HashMap<>();
		Map<String, List<String>> parms = new HashMap<>();
		
		String uri = null;
		try {
			uri = HttpParsing.parseRequest(
					((InetSocketAddress) socket.getRemoteSocketAddress()).getHostName(),
					socket.getInputStream(), 
					headers,
					parms);
		} catch (HaltException | IOException e) {
			e.printStackTrace();
		}
		
		worker_url = uri;
		//Construct request and response objects
		logger.info("Create request and response objects");
		HttpRequest request = new HttpRequest(uri, socket, headers, parms);
		HttpResponse response = new HttpResponse(socket, request);
		
		//Get user-agent in request and set to response header "server"
		response.addHeader("server", request.userAgent());
		
		//Get Current Date Time in GMT and set to response header "date"
		SimpleDateFormat gmtDateFormat = new SimpleDateFormat("EE, dd MMM yyyy HH:mm:ss zzz");
		gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		response.addHeader("date", gmtDateFormat.format(new Date()));

		//Handle request
		RequestHandler.handle(webservice, request, response);
		
		//Send response or exception based on modified response status
		if (response.status()==200) {
			logger.info("200, Send Response");
			sendResponse(socket, request, response);
		}else {
			
			HaltException ex = new HaltException(response.status());
			logger.info("not 200, Send Exception" + ex.statusCode());
			sendException(socket, request, ex);
		}
		
		worker_url = null;
		return request;
		
    }
}
