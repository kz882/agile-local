package edu.upenn.cis.cis455.m1.interfaces;

import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.upenn.cis.cis455.m2.interfaces.HttpSession;
import edu.upenn.cis.cis455.m2.interfaces.Session;

public class HttpRequest extends edu.upenn.cis.cis455.m2.interfaces.Request {
	
	boolean persistent = false;
	private String uri;
	
	private Map<String, String> headers;
	private Map<String, List<String>> parms;
	private Socket socket;
	
	protected Session session;
	protected Map<String, String> params;
	protected Map<String, Object> attributes;
	protected Map<String, String> cookies;
	
	public HttpRequest(String uri, Socket socket, Map<String, String> headers, Map<String, List<String>> parms) {
		this.uri = uri;
		this.socket = socket;
		this.headers = headers;
		this.parms = parms;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}
	
	@Override
	public String requestMethod() {
		return this.headers("Method");
	}

	@Override
	public String host() {
		return this.headers.get("host");
	}

	@Override
	public String userAgent() {
		return this.headers.get("user-agent");
	}

	@Override
	public int port() {
		return this.socket.getLocalPort();
	}

	@Override
	public String pathInfo() {
		return this.uri;
	}

	@Override
	public String url() {
		return this.uri + this.headers.get("queryString");
	}

	@Override
	public String uri() {
		return this.uri;
	}

	@Override
	public String protocol() {
		return this.headers.get("protocolVersion");
	}

	@Override
	public String contentType() {
		return this.headers.get("content-type");
	}

	@Override
	public String ip() {
		return this.socket.getLocalAddress().getHostAddress();
	}

	@Override
	public String body() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int contentLength() {
		return Integer.parseInt(headers.get("content-length"));
	}

	@Override
	public String headers(String name) {
		return this.headers.get(name);
	}

	@Override
	public Set<String> headers() {
		return this.headers.keySet();
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	@Override
	public Session session() {
		if(this.session == null) {
			this.session = session(true);
			return this.session;
		}
		if(this.session.maxInactiveInterval();)
		return this.session;
	}

	@Override
	public Session session(boolean create) {
		// TODO Auto-generated method stub
		if(create) {
			this.session = HttpSession.HttpSession();
		}
		return this.session;
	}

	@Override
	public Map<String, String> params() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String queryParams(String param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> queryParamsValues(String param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<String> queryParams() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String queryString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void attribute(String attrib, Object val) {
		// TODO Auto-generated method stub
		this.attributes.put(attrib, val);
	}

	@Override
	public Object attribute(String attrib) {
		// TODO Auto-generated method stub
		return this.attributes.get("attrib");
	}

	@Override
	public Set<String> attributes() {
		// TODO Auto-generated method stub
		return this.attributes.keySet();
	}

	@Override
	public Map<String, String> cookies() {
		return this.cookies;
	}

	
}
