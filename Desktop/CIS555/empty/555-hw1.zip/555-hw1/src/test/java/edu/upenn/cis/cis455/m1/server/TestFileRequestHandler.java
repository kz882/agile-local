package edu.upenn.cis.cis455.m1.server;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.upenn.cis.cis455.m1.handling.FileRequestHandler;
import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;

import org.apache.logging.log4j.Level;

public class TestFileRequestHandler {
    @Before
    public void setUp() {
        org.apache.logging.log4j.core.config.Configurator.setLevel("edu.upenn.cis.cis455", Level.DEBUG);
    }
    
    @Test
    public void testFileRequestHandler() throws IOException {
        HttpRequest request = new HttpRequest("index.html", null, null, null);
        byte[] realBytes = Files.readAllBytes(Paths.get("www/index.html"));
        
        HttpResponse response = new HttpResponse(null, request);
        FileRequestHandler.handle(request, response);
        
        assertArrayEquals(response.bodyRaw(), realBytes);
        assertEquals(response.type(), "text/html");
    }
    
    @Test
    public void test404() throws IOException {
        HttpRequest request = new HttpRequest("qqq", null, null, null);
        
        HttpResponse response = new HttpResponse(null, request);
        FileRequestHandler.handle(request, response);
        
        assertEquals(response.status(), 404);
    }
    
    @Test
    public void test403() throws IOException {
        HttpRequest request = new HttpRequest("../mydir/index.html", null, null, null);
        
        HttpResponse response = new HttpResponse(null, request);
        FileRequestHandler.handle(request, response);
        
        assertEquals(response.status(), 403);
    }
    
    @Test
    public void testWWW() throws IOException {
        HttpRequest request = new HttpRequest("../www", null, null, null);
        byte[] realBytes = Files.readAllBytes(Paths.get("www/index.html"));
        
        HttpResponse response = new HttpResponse(null, request);
        FileRequestHandler.handle(request, response);
        
        
        assertArrayEquals(response.bodyRaw(), realBytes);
        assertEquals(response.type(), "text/html");
    }
    
    
    @After
    public void tearDown() {}
}
