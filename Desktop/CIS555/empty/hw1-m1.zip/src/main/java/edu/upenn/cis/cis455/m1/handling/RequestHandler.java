package edu.upenn.cis.cis455.m1.handling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;
import edu.upenn.cis.cis455.m1.server.WebService;

public class RequestHandler {
    final static Logger logger = LogManager.getLogger(RequestHandler.class);
    
	public static void get(WebService webservice, HttpRequest request, HttpResponse response) {
		logger.info("Check for special urls and execute accordingly");
		if(request.uri().equals("/control")) {
			webservice.control(request, response);
		}else if(request.uri().equals("/shutdown")) {
			FileRequestHandler.handle(request, response);
			webservice.stop(request, response);
		}else {
			FileRequestHandler.handle(request, response);
		}
	}
	
	public static void head(HttpRequest request, HttpResponse response) {
		FileRequestHandler.handle(request, response);
	}

	public static void handle(WebService webservice, HttpRequest request, HttpResponse response) {
		if(request.requestMethod() == null) {
			return;
		}
		else if(request.requestMethod().equals("GET")) {
			get(webservice, request, response);
		}else if(request.requestMethod().equals("HEAD")) {
			head(request, response);
		}else {
			return;
		}
		
	}
}
