package edu.upenn.cis.cis455.m1.interfaces;

import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HttpRequest extends Request {
	
	boolean persistent = false;
	private String uri;
	
	private Map<String, String> headers;
	private Map<String, List<String>> parms;
	private Socket socket;
	
	public HttpRequest(String uri, Socket socket, Map<String, String> headers, Map<String, List<String>> parms) {
		this.uri = uri;
		this.socket = socket;
		this.headers = headers;
		this.parms = parms;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}
	
	@Override
	public String requestMethod() {
		return this.headers("Method");
	}

	@Override
	public String host() {
		// TODO Auto-generated method stub
		return this.headers.get("host");
	}

	@Override
	public String userAgent() {
		// TODO Auto-generated method stub
		return this.headers.get("user-agent");
	}

	@Override
	public int port() {
		// TODO Auto-generated method stub
		return this.socket.getLocalPort();
	}

	@Override
	public String pathInfo() {
		// TODO Auto-generated method stub
		return this.uri;
	}

	@Override
	public String url() {
		// TODO Auto-generated method stub
		return this.uri + this.headers.get("queryString");
	}

	@Override
	public String uri() {
		// TODO Auto-generated method stub
		return this.uri;
	}

	@Override
	public String protocol() {
		// TODO Auto-generated method stub
		return this.headers.get("protocolVersion");
	}

	@Override
	public String contentType() {
		// TODO Auto-generated method stub
		return this.headers.get("content-type");
	}

	@Override
	public String ip() {
		// TODO Auto-generated method stub
		return this.socket.getLocalAddress().getHostAddress();
	}

	@Override
	public String body() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int contentLength() {
		// TODO Auto-generated method stub
		return Integer.parseInt(headers.get("content-length"));
	}

	@Override
	public String headers(String name) {
		return this.headers.get(name);
	}

	@Override
	public Set<String> headers() {
		return this.headers.keySet();
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	
}
