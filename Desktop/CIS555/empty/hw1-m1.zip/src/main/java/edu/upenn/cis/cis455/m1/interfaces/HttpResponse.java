package edu.upenn.cis.cis455.m1.interfaces;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class HttpResponse extends Response{
    protected Socket socket;
    protected HttpRequest request;
    protected Map<String, String> headers = new HashMap<String, String>();
    
	public HttpResponse(Socket socket, HttpRequest request) {
		super();
		this.socket = socket;
		this.request = request;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	@Override
	public String getHeaders() {
		//return a String of headers without new line in the end
    	StringBuilder sb = new StringBuilder();
    	sb.append("Date: " + this.headers.get("date") + "\r\n");
    	sb.append("Content-Type: " + this.contentType + "\r\n");
    	sb.append("Content-Length: " + this.contentLength + "\r\n");
    	return sb.toString();
	}
	
	public Map<String, String> Headers(){
		return this.headers;
	}
	
	public void addHeader(String field, String value) {
		this.Headers().put(field, value);
	}

}
