package edu.upenn.cis.cis455.m1.server;

import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Stub for your HTTP server, which listens on a ServerSocket and handles
 * requests
 */
public class HttpListener implements Runnable {
	
	static final Logger logger = LogManager.getLogger(HttpListener.class);	

	private WebService webservice;
	private HttpTaskQueue sharedQueue;
	private int maxQueueSize;
	private int port = 45556;
	private String ipaddress = "0.0.0.0";
	private int task_num = 0;
	
	public HttpListener() {
	}
	
	public HttpListener(WebService webservice, HttpTaskQueue sharedQueue, int maxQueueSize, int port, String ipaddress) {
		this.webservice = webservice;
		this.sharedQueue = sharedQueue;
		this.maxQueueSize = maxQueueSize;
		this.port = port;
		this.ipaddress = ipaddress;
	}

	public HttpTaskQueue getSharedQueue() {
		return sharedQueue;
	}

	public void setTaskQueue(HttpTaskQueue sharedQueue) {
		this.sharedQueue = sharedQueue;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * Method which pushes an element passed as argument to shared queue.
	 * @param i - item to be added
	 * @throws InterruptedException
	 */
	public void addToQueue(HttpTaskQueue taskQueue, HttpTask task) throws InterruptedException {
		logger.info("Adding element to queue");//This would be logged in the log file created and to the console.
		//wait if the queue is full
		while (true) {
			synchronized (sharedQueue) {
				if (sharedQueue.size() == this.maxQueueSize) {
					// Synchronizing on the sharedQueue to make sure no more than one
					// thread is accessing the queue same time.
					logger.debug("Queue is full!");
					sharedQueue.wait();
					// We use wait as a way to avoid polling the queue to see if
					// there was any space for the producer to push.
				} else {
					//Adding element to queue and notifying all waiting consumers
					sharedQueue.taskQueue.add(task);
					logger.debug("Notifying after add");//This would be logged in the log file created and to the console.
					sharedQueue.notifyAll();
					break;
				}
			}
		}
	}
	
	
	
    @Override
    public void run(){
    	//Keeps listening on serverSocket till webservice not active
    	try{
    		ServerSocket serverSocket = new ServerSocket();
    		serverSocket.bind(new InetSocketAddress(ipaddress, port));
    		this.webservice.serversocket = serverSocket;
    		
    		//Adding tasks to queue, or wait till not full queue
	    	while (this.webservice.active) {
	    		Socket socket = serverSocket.accept();
	    		HttpTask task = new HttpTask(socket);
	
	    		try {
					logger.debug("HttpListener pushed: " + task_num + " onto shared queue");
					task_num ++;
					addToQueue(sharedQueue, task);
				} catch (Exception ex) {
					logger.error("Exception in HttpListener thread." + ex.toString());
					break;
				}
	    	}
    	}catch(Exception e) {
    		if (e instanceof SocketException) {
    			logger.info("Socket Exception");
    			return;
    		}
    		e.printStackTrace();
    	}
    }
}

