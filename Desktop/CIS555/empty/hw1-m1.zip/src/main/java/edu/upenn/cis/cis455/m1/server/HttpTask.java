package edu.upenn.cis.cis455.m1.server;

import java.net.Socket;

import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;

public class HttpTask {
    Socket requestSocket;
    HttpRequest request;
    HttpResponse response;

    public HttpTask(Socket socket) {
        requestSocket = socket;
    }

    public Socket getSocket() {
        return requestSocket;
    }
}
