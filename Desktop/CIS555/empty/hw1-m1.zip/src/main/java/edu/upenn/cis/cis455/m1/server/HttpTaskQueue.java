package edu.upenn.cis.cis455.m1.server;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Stub class for implementing the queue of HttpTasks
 */
public class HttpTaskQueue{
	
	static final Logger logger = LogManager.getLogger(HttpTaskQueue.class);	
	
	//create workers and assign tasks to them
	private int maxQueueSize;
	public ArrayList<HttpTask> taskQueue;
	
	public HttpTaskQueue(int maxQueueSize) {
		this.maxQueueSize = maxQueueSize;
		this.taskQueue = new ArrayList<>();
	}

	public int getMaxQueueSize() {
		return maxQueueSize;
	}

	public void setMaxQueueSize(int maxQueueSize) {
		this.maxQueueSize = maxQueueSize;
	}

	public ArrayList<HttpTask> getTaskQueue() {
		return taskQueue;
	}

	public void setTaskQueue(ArrayList<HttpTask> taskQueue) {
		this.taskQueue = taskQueue;
	}

	public int size() {
		return this.taskQueue.size();
	}

	public boolean isEmpty() {
		return this.taskQueue.isEmpty();
	}

	public HttpTask remove(int i) {
		return this.taskQueue.remove(i);
	}

	

	
}
