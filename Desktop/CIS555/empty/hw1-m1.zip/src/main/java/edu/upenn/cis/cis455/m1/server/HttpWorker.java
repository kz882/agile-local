package edu.upenn.cis.cis455.m1.server;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.cis.cis455.exceptions.HaltException;
import edu.upenn.cis.cis455.m1.handling.HttpIoHandler;


/**
 * Stub class for a thread worker that handles Web requests
 */
public class HttpWorker implements Runnable {

	static final Logger logger = LogManager.getLogger(HttpListener.class);	

	private WebService webservice;
	private HttpTaskQueue sharedQueue;
	private int maxQueueSize;
	private String url;
	
	public HttpWorker(WebService webservice, HttpTaskQueue sharedQueue, int maxQueueSize, int port, String ipaddress) {
		this.webservice = webservice;
		this.sharedQueue = sharedQueue;
		this.maxQueueSize = maxQueueSize;
	}

	public HttpTaskQueue getSharedQueue() {
		return sharedQueue;
	}

	public void setSharedQueue(HttpTaskQueue sharedQueue) {
		this.sharedQueue = sharedQueue;
	}

	public int getMaxQueueSize() {
		return maxQueueSize;
	}

	public void setMaxQueueSize(int maxQueueSize) {
		this.maxQueueSize = maxQueueSize;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Method to read from the queue.
	 * @return - element read from queue
	 * @throws InterruptedException
	 */
	private HttpTask readFromQueue() throws InterruptedException {
		while (true) {
			synchronized (sharedQueue) {
				if (sharedQueue.isEmpty()) {
					//If the queue is empty, we push the current thread to waiting state. Way to avoid polling.
					logger.debug("Queue is currently empty");
					sharedQueue.wait();
				} else {
					HttpTask task = sharedQueue.remove(0);
					logger.debug("Notifying everyone we are removing an item");
					sharedQueue.notifyAll();
					logger.debug("Exiting queue with return");
					return task;
				}
			}
		}
	}
	
    @Override
    public void run() {
    	logger.debug("running a new Worker Thread");
    	while(this.webservice.active) {
			try {
				HttpTask taskReadFromQueue = readFromQueue();
				logger.debug("Consumed " + taskReadFromQueue +" from shared queue");
				HttpIoHandler.handleRequest(this.url, webservice, taskReadFromQueue.getSocket());
				Thread.sleep(100);
			} catch (InterruptedException | HaltException e) {
				logger.error("Interrupt Exception in Consumer thread");
			}
		}
    	
    }

}
