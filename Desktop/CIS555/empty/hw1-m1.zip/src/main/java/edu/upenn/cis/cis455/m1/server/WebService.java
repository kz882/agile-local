/**
 * CIS 455/555 route-based HTTP framework
 * 
 * V. Liu, Z. Ives
 * 
 * Portions excerpted from or inspired by Spark Framework, 
 * 
 *                 http://sparkjava.com,
 * 
 * with license notice included below.
 */

/*
 * Copyright 2011- Per Wendel
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.upenn.cis.cis455.m1.server;


//import java.io.File;
import java.io.IOException;
import java.lang.Thread.State;
//import java.net.InetSocketAddress;
//import java.net.MalformedURLException;
import java.net.ServerSocket;
//import java.net.Socket;
//import java.net.URL;
//import java.nio.file.Path;
//import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import edu.upenn.cis.cis455.exceptions.HaltException;
import edu.upenn.cis.cis455.m1.handling.FileRequestHandler;
import edu.upenn.cis.cis455.m1.handling.HttpIoHandler;
import edu.upenn.cis.cis455.m1.interfaces.HttpRequest;
import edu.upenn.cis.cis455.m1.interfaces.HttpResponse;

public class WebService {
    final static Logger logger = LogManager.getLogger(WebService.class);
    private int port=45555;
    private String rootDir="./www";
    private String ipaddress="0.0.0.0";
    
    protected HttpWorker worker;
    protected HttpListener listener;
    protected HttpTaskQueue sharedQueue;
    protected int maxQueueSize;
    protected int threadPoolSize;
    
    protected ArrayList<Thread> workerThreads = new ArrayList<>();
    protected ArrayList<HttpWorker> workers = new ArrayList<>();
    protected Thread listenerThread;
    protected boolean active = false;
	protected ServerSocket serversocket;
    
    //store routes for m2
    
    /**
     * Launches the Web server thread pool and the listener
     */
    public void start() {
    	//Set sharedQueue
    	this.active = true;
    	maxQueueSize = 4;
    	HttpTaskQueue sharedQueue = new HttpTaskQueue(maxQueueSize);
    	this.sharedQueue = sharedQueue;
    	
    	//Start 1 listener thread
    	HttpListener listener = new HttpListener(this, sharedQueue, maxQueueSize, port, ipaddress);
    	Thread listenerThread = new Thread(listener);
    	this.listenerThread = listenerThread;
    	listenerThread.start();

    	//Start threadPoolSize number of worker threads
    	for (int i=0; i<threadPoolSize; i++) {
    		HttpWorker worker = new HttpWorker(this, sharedQueue, maxQueueSize, port, ipaddress);
    		this.workers.add(worker);
    		Thread workerThread = new Thread(worker);
    		this.workerThreads.add(workerThread);
    		workerThread.start();
    	}
    }

    /**
     * Gracefully shut down the server
     */
    public void stop(HttpRequest request, HttpResponse response) {
    	//Send shutdown.html as response
    	logger.info("Stopping the server");
    	response.status(200);
    	
    	request.setUri("/shutdown.html");
    	FileRequestHandler.handle(request, response);
    	
    	HttpIoHandler.sendResponse(request.getSocket(), request, response);
    	
    	//Notify all threads and wait until they are all shutdown
    	synchronized(this.sharedQueue) {
	    	this.active = false;
	    	this.sharedQueue.notifyAll();
    	}
    	
    	//Close serverSocket when all threads finished working and exit the main
    	try {
			this.serversocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	System.exit(0);
    }

    /**
     * Hold until the server is fully initialized.
     * Should be called after everything else.
     */
    public void awaitInitialization() {
        logger.info("Initializing server");
        start();
    }

    /**
     * Triggers a HaltException that terminates the request
     */
    public HaltException halt() {
        throw new HaltException();
    }

    /**
     * Triggers a HaltException that terminates the request
     */
    public HaltException halt(int statusCode) {
        throw new HaltException(statusCode);
    }

    /**
     * Triggers a HaltException that terminates the request
     */
    public HaltException halt(String body) {
        throw new HaltException(body);
    }

    /**
     * Triggers a HaltException that terminates the request
     */
    public HaltException halt(int statusCode, String body) {
        throw new HaltException(statusCode, body);
    }

    ////////////////////////////////////////////
    // Server configuration
    ////////////////////////////////////////////

    /**
     * Set the root directory of the "static web" files
     */
    public void staticFileLocation(String directory) {
    	this.rootDir = directory;
    	FileRequestHandler.setRootDir(directory);
    }

    /**
     * Set the IP address to listen on (default 0.0.0.0)
     */
    public void ipAddress(String ipAddress) {
    	this.ipaddress = ipAddress;
    }

    /**
     * Set the TCP port to listen on (default 45555)
     */
    public void port(int port) {
    	this.port = port;
    }

    /**
     * Set the size of the thread pool
     */
    public void threadPool(int threads) {
    	this.threadPoolSize = threads;
    }
    
    ////////////////////////////////////////////
    // Worker Threads
    ////////////////////////////////////////////
    // The control panel for the GET /control request
    public void control(HttpRequest request, HttpResponse response) {
    	//Construct control panel page
    	StringBuilder sb = new StringBuilder();
		String shutdown = "/shutdown";
		
		sb.append("<html>\r\n");
		sb.append("<head>\r\n");
		sb.append("<title>Control Panel</title>\r\n");
		sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n");
		sb.append("</head>\r\n");
		sb.append("<body>\r\n");
		
		sb.append("<p>Control Panel</p>\r\n");
		for (int i=0; i<this.workerThreads.size(); i++) {
			State state = this.workerThreads.get(i).getState();
			String worker_url = this.workers.get(i).getUrl();
			if(worker_url != null && !worker_url.isEmpty()) {
				sb.append("<p>Workder Thread: " + i + " " + state.toString() + " " + worker_url + "</p>\r\n");
			}else {
				sb.append("<p>Workder Thread: " + i + " " + state.toString() + "</p>\r\n");
			}
			
		}
		
		sb.append("<a href=" + shutdown+ ">Shut Down</a>\r\n");
		sb.append("</body>\r\n");
		sb.append("</html>\r\n");
         
		response.status(200);
		response.type("text/html");
		response.length(sb.length());
		response.body(sb.toString());

    	
    }


}
